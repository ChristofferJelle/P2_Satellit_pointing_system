
void PID() {
  double gap = abs(setpoint - kalAngleZ);  //distance away from setpoint

  if (gap < 50) {  //we're close to setpoint, use conservative tuning parameters
    myPID.SetTunings(consKp, consKi, consKd);
  } else {
    //we're far from setpoint, use aggressive tuning parameters
    myPID.SetTunings(aggKp, aggKi, aggKd);
  }

  myPID.Compute();
  //output is caluclated from myPID.compute the closer it is to setpoint, the less power coil getting if any when at setpoint.
  if (kalAngleZ > setpoint) {
    //StartCoil(1, Output, 10, true);
    StartCoil(2, Output, 10, false);
  } else if (kalAngleZ < setpoint) {
    //StartCoil(1, Output, 10, false);
    StartCoil(2, Output, 10, true);
  }
}
